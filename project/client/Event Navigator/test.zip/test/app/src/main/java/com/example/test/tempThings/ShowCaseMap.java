package com.example.test.tempThings;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;

import com.example.test.R;
import com.example.test.Server.Server;
import com.example.test.model.Event;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class ShowCaseMap extends Fragment {
    public static ShowCaseMap newInstance(long id) {
        Bundle args = new Bundle();
        args.putLong("id", id);
        ShowCaseMap fragment = new ShowCaseMap();
        fragment.setArguments(args);
        return fragment;
    }

    public void update(Event event) {
        showEvent = event;
        SupportMapFragment mapFragment =
                (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.show_map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(callback);
        }
    }

    private Event showEvent;
    private final OnMapReadyCallback callback = new OnMapReadyCallback() {

        @Override
        public void onMapReady(GoogleMap googleMap) {
            googleMap.moveCamera(CameraUpdateFactory.newLatLng(new LatLng(showEvent.getX(), showEvent.getY())));
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(showEvent.getX(), showEvent.getY()), 9.0f));
            googleMap.addMarker(new MarkerOptions().position(new LatLng(showEvent.getX(), showEvent.getY())).title(showEvent.getName()).snippet(showEvent.getDescription()));
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                return;
            }
            googleMap.setMyLocationEnabled(true);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_show_case_map, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        long id = 0;
        if (getArguments() != null) {
            id = getArguments().getLong("id");
        }
        showEvent = null;
        Server.getEventById((int) id, getActivity(), ShowCaseMap.this);
    }


}