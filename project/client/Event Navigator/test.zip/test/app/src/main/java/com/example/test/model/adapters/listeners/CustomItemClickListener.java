package com.example.test.model.adapters.listeners;

import android.view.View;

public interface CustomItemClickListener {
    void onItemClick(View v, int position);
}
